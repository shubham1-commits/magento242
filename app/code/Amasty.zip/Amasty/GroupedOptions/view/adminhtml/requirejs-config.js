var config = {
    map: {
        '*': {
            amSearchOptions: 'Amasty_GroupedOptions/js/search-options'
        }
    }
};
