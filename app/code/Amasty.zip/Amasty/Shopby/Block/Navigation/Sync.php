<?php

namespace Amasty\Shopby\Block\Navigation;

/**
 * @api
 */
class Sync extends \Magento\Framework\View\Element\Template
{
    /**
     * Path to template file in theme.
     *
     * @var string
     */
    protected $_template = 'navigation/sync.phtml';
}
