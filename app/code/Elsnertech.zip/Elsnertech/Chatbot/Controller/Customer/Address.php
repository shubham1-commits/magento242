<?php
namespace Elsnertech\Chatbot\Controller\Customer;

class Address extends \Magento\Framework\App\Action\Action
{

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $customer,
        \Elsnertech\Chatbot\Model\CustomerApi $customerapi,
        \Magento\Framework\App\RequestInterface $request
    ) {
        $this->customer = $customer;
        $this->request = $request;
        $this->_customerapi = $customerapi;
        return parent::__construct($context);
    }

    public function execute()
    {
        $customer = $this->customer;
        if ($customer->isLoggedIn()) {
            $customerId = $customer->getId();
            $this->_customerapi->customerAddress($customerId);
        } else {
            $res = 'Click Yes to create new Account';
            $res = $this->json->serialize($res);
            echo $res;
        }
    }
}
