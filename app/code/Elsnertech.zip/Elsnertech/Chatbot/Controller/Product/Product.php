<?php
namespace Elsnertech\Chatbot\Controller\Product;

class Product extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $customer,
        \Elsnertech\Chatbot\Model\ProductApi $productapi,
        \Magento\Framework\App\RequestInterface $request
    ) {
        $this->customer = $customer;
        $this->request = $request;
        $this->_productapi = $productapi;
        parent::__construct($context);
    }

    public function execute()
    {
        $customer = $this->customer;
        if ($customer->isLoggedIn()) {
            $sku = $this->request->getParam('numone');
            $customerId = $customer->getId();
            $this->_productapi->productShow($sku, $customerId);
        } else {
            $res =  "customer is not login";
            echo $res;
        }
    }
}
