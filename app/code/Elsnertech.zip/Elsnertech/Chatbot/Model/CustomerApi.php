<?php
namespace Elsnertech\Chatbot\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

class CustomerApi extends \Magento\Framework\Model\AbstractModel
{
    public function __construct(
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Framework\Serialize\Serializer\Json $json
    ) {
        $this->customerFactory = $customerFactory;
        $this->json = $json;
    }

    public function customerAddress($id)
    {
        $address = $this->customerFactory->create();
        $address = $address->load($id);
        $addresses = $address->getAddresses();
        if (!empty($addresses)) {
            foreach ($addresses as $key) {
                $postcode = $key->getpostcode();
                $city = $key->getcity();
                $company = $key->getcompany();
                $region = $key->getregion();
                $country = $key->getcountry();
                $phone = $key->gettelephone();
              
                if (isset($company) and isset($region)) {
                    $address = 'company name is'." ".$company." ".'city is'." ".$city." "."country is"." ".$country." "."phone is"." ".$phone." "."region is"." ".$region;
                } else {
                    $address = 'city is'." ".$city." "."country is"." ".$country." "."phone is"." ".$phone;
                }
                // $this->_api->chatStore($post,$address);
                $res = $this->json->serialize($address);
                echo $res;
            }
        } else {
                $res = 'Address is not set';
                $res = $this->json->serialize($res);
                echo $res;
        }
    }
}
