<?php
namespace Elsnertech\Chatbot\Model;

/**
 * Class OrderApi
 *
 * @package Elsnertech\Zohointegration\Model
 */

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

class OrderApi extends \Magento\Framework\Model\AbstractModel
{

    public function __construct(
        \Magento\Customer\Model\CustomerFactory $_customerloader,
        \Magento\Framework\Serialize\Serializer\Json $json,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
    ) {
        $this->_customerloader = $_customerloader;
        $this->_json = $json;
        $this->_orderFactory = $orderFactory;
        $this->orderCollectionFactory = $orderCollectionFactory;
    }

    public function orderStatus($customerId)
    {
        $customerOrder = $this->orderCollectionFactory->create()->addFieldToFilter('customer_id', $customerId);
        $t = count($customerOrder);
        $data = $customerOrder->getdata();
        if ($t!=0) {
            foreach ($data as $key) {
                $id = $key['increment_id'];
                //$this->_api->chatStore($post,$id);
                $post = " ";
                $jsonArray[] = ["increment_id"=>$id];
            }
            $res = $this->_json->serialize($jsonArray);
            echo $res;
        } else {
            $jsonArray[] = "Order is not avalible";
            $res = $this->_json->serialize($jsonArray);
            echo $res;
        }
    }


    public function orderStatusinfo($post)
    {
            $order = $this->_orderFactory->create();
            $order = $order->loadByIncrementId($post);
            $shipcharge = $order->getShippingAmount();
            $customerid = $order->getCustomerId();
            $status = $order->getstatus();
            $orderItems = $order->getAllItems();
            $grandtotal = $order->getGrandTotal();
            $itemQty = [];
        foreach ($orderItems as $item) {
            $productname =  $item->getName();
            $producttype = $item->getProductType();
            if ($producttype!="configurable") {
                $res = [
                    "productname"=>$productname,
                    "status" => $status
                ];
                $rece[] = "productname is"." ".$productname." "."status is"." ".$status;
                //$this->_api->chatStore(" ",$rece);
            }
        }
            $res = $this->_json->serialize($rece);
            echo $res;
    }

    public function orderListinfo($id)
    {
        $order = $this->_orderFactory->create();
        $order = $order->loadByIncrementId($id);
        $shipcharge = $order->getshipping_amount();
        $customerid = $order->getCustomerId();
        $orderItems = $order->getAllItems();
        $grandtotal = $order->getbase_grand_total();
        $shipping = $order->getShippingAddress()->getData();
        $billing = $order->getBillingAddress()->getData();
        $itemQty = [];
        foreach ($orderItems as $item) {
            $qty = $item->getQtyOrdered();
            $total = $item->getrow_total();
            $price = $item->getprice();
            $productname =  $item->getname();
            if ($price!=0) {
                $price = $item->getPrice();
                $r[] = "product name is"." ".$productname." "."Qty is"." ".$qty." "."Total price is"." ".$total;
                //$this->_api->chatStore(" ",$r);
                $res = $this->_json->serialize($r);
                
            }
        }
        echo $res;
    }
}
