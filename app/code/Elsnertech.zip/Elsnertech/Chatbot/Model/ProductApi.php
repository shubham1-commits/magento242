<?php
namespace Elsnertech\Chatbot\Model;

/**
 * Class ProductApi
 *
 * @package Elsnertech\Chatbot\Model
 */

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

class ProductApi extends \Magento\Framework\Model\AbstractModel
{

    public function __construct(
        \Magento\Framework\Serialize\Serializer\Json $json,
        \Magento\Wishlist\Model\WishlistFactory $wishlistRepository,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Catalog\Model\ProductFactory $_productloader
    ) {
        $this->_json = $json;
        $this->_wishlistRepository= $wishlistRepository;
        $this->_productRepository = $productRepository;
        $this->_cart = $cart;
        $this->_productloader = $_productloader;
        $this->formKey = $formKey;
    }

    public function productShow($sku, $customerId)
    {
        $product = $this->_productRepository->get($sku);
        $id = $product->getid();
        $product = $this->_productRepository->getById($id);
        $wishlist = $this->_wishlistRepository->create()->loadByCustomerId($customerId, true);
        $productimages = $product->getMediaGalleryImages();
        foreach ($productimages as $productimage) {
            $res = "<div class='product-img-wrap'><img src = ".$productimage['url']. " height=100 width=100 /></div><div class='product-action-btn'><button value='$sku' class='maincart1'>Addtocart</button><button value='$sku' class='wish'>wishlist</button></div>";
        }
        echo $res;
    }

    public function wishList($sku, $customerId)
    {
        $product = $this->_productRepository->get($sku);
        $id = $product->getid();
        $product = $this->_productRepository->getById($id);
        $wishlist = $this->_wishlistRepository->create()->loadByCustomerId($customerId, true);
        $wishlist->addNewItem($product);
        $wishlist->save();
        $res = 'wishlist is Add';
        echo $res;
    }

    public function cartItem($sku)
    {
        $qty = 1;
        $product = $this->_productRepository->get($sku);
        $id = $product->getid();
        $producttype = $product->gettype_id();
        if ($producttype=="downloadable" or $producttype=="virtual" or $producttype=="simple") {
            $params = [
                'form_key' => $this->formKey->getFormKey(),
                'product' => $id,
                'qty'   =>1
            ];
            $product = $this->_productRepository->getById($id);
            $proname = $product->getname();
            $this->_cart->addProduct($product, $params);
            $this->_cart->save();
            $res = '<div class="reci-wrapper" style="display: inline-block;"><p id="reci">'."Product"." ".$proname."is Add to cart".'</p></div>';
            echo $res;
        } elseif ($producttype=='bundle') {
                $product = $this->_productRepository->getById($id);
                $proname = $product->getname();
                $selectionCollection = $product->getTypeInstance(true)->getSelectionsCollection($product->getTypeInstance(true)->getOptionsIds($product), $product);
            foreach ($selectionCollection as $proselection) {
                $params['bundle_option'][$proselection->getOptionId()] = $proselection->getSelectionId();
            }
                $this->_cart->addProduct($product, $params);
                $this->_cart->save();
                $res = '<div class="reci-wrapper" style="display: inline-block;"><p id="reci">'."Product"." ".$proname."is Add to cart".'</p></div>';
                echo $res;

        } elseif ($producttype=='grouped') {
                $product = $this->_productRepository->getById($id);
                $childProductCollection = $product->getTypeInstance()->getAssociatedProducts($product);
                
                $child_qty = 2;

            foreach ($childProductCollection as $child) {
                $super_group[] = $child_qty;
            }
                $params = ['qty'=>1];
                $this->_cart->addProduct($product, $params);
                $this->_cart->save();

        }
    }
}
