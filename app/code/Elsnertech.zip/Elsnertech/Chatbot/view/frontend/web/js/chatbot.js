define(['jquery'], function ($) {
    "use strict";
    $(document).ready(function () {
 
        var test = jQuery('#url').val(); 
        var testvariable = "testdata";

        var menudisplay = function() {
            $(".quick-replies").css("display", "flex");
        }

        var nonloginajax = function(url,info) {
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    numone: info
                },
                cache: false,
                success: function (response) {
                    $('.msg-wrap').append(response);
                }
            });
        }
    
        var receivermsg = function (msg) {
            var receiver = "<div class='reci-wrapper' style='display: inline-block;'><p id='reci'>"+msg+"</p></div>";
            $('.msg-wrap').append(receiver);
            if (msg=="Geast is save") {
                menudisplay();                
            }
        }

        $('.open-button').click(function () {
            var url = test + "chatbot/index/index";
            var info = $('.msg-wrap').html();
            nonloginajax(url,info);
        });

        $(document).on('click', '.newcustomer', function () {
            var url = test + "chatbot/index/newcustomer";
            var name = $('#name').val();            
            var email = $('#email').val();
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    name: name,
                    email :email
                },
                cache: false,
                success: function (response) {
                    receivermsg(response);
                }
            });
        });

        $(document).on('click','#order',function () {
            parentremove();
            var url = test + "chatboat/management/order";
            childlink(url, oneValue);
        });

    });
});
