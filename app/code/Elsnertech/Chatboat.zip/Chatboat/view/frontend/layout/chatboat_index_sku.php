<?php xml version="1.0"?>
<page xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" layout="1column" xsi:noNamespaceSchemaLocation="urn:magento:framework:View/Layout/etc/page_configuration.xsd">
    <referenceContainer name="content">
        <block class="Elsnertech\Chatboat\Block\Initialchatboat" name="sku" template="Elsnertech_Chatboat::sku.phtml" />
    </referenceContainer>
</page>