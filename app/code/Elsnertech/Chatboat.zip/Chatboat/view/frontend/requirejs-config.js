var config = {
    map: {
        '*': {
            myscript: 'Elsnertech_Chatboat/js/chatbot',
        }
    }
};