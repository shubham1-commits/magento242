var config = {
    map: {
        '*': {
            myscript: 'Elsnertech_Zohointegration/js/custom',
        }
    }
};