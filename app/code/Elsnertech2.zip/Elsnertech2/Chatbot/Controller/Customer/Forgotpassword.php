<?php
namespace Elsnertech\Chatbot\Controller\Customer;

class Forgotpassword extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Elsnertech\Chatbot\Model\Api $api,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Customer\Api\AccountManagementInterface $customerAccountManagement,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
    ) {
        $this->customer = $customerSession;
        $this->_api = $api;
        $this->request = $request;
        $this->customerAccountManagement = $customerAccountManagement;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
        parent::__construct($context);
    }

    public function execute()
    {

        if ($this->customer->isLoggedIn()) {
            $customer = $this->customer;
            $customerId = $customer->getId();
            $customer = $this->_customerRepositoryInterface->getById($customerId);
            $email = $customer->getEmail();
        } else {
            $email = $this->request->getParam('numone');
        }
        if (!\Zend_Validate::is($email, 'EmailAddress')) {
                $this->customer->setForgottenEmail($email);
            }
        try {
            $this->customerAccountManagement->initiatePasswordReset($email, $this->customerAccountManagement::EMAIL_RESET);
            echo "Reset password link send succesfully please check mail";
            // $this->_api->chatStore(" ","Email is send");
        } catch (\Exception $e) {
            echo "Eail send many requested please check mail ";
        }
    }
}
