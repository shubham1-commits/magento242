<?php
namespace Elsnertech\Chatbot\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Elsnertech\Chatbot\Model\Api $api,
        \Elsnertech\Chatbot\Model\CustomerchatFactory $customerchatFactory,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Customer\Model\Session $customerSession
    ) {
        $this->_customerSession = $customerSession;
        $this->_customerchatFactory = $customerchatFactory;
        $this->_api = $api;
        $this->request = $request;
        return parent::__construct($context);
    }

    public function execute()
    {   
        $id = $this->request->getParam('numone');
        $customer = $this->_customerSession;
        $customerId = $customer->getId();
        $data = $this->_customerchatFactory->create();
        if ($customer->isLoggedIn()) {
                $a  = $data->getCollection()->addFilter('customerid',['in' => $customerId]);
                foreach ($a as $key) {
                    $setmsg = $key->getwelcomemsg();
                }
                if (isset($setmsg) && $setmsg=="1") {
                    $msg = "🙌 Welcome back! How may I help you today? 🤖";
                    $this->_api->chatStore(" ",$msg);
                    $res = '<div class="reci-wrapper" style="display: inline-block;"><p id="reci">🙌 Welcome back! How may I help you today? 🤖</p></div>';
                   echo $res;
                } else {
                    $data = "👋 Hi ! I m a Bot. Let me know if you have any questions regarding our tool!";
                    $data1 = "Select the topic or write your question below.";
                    $res = '<div class="reci-wrapper" style="display: inline-block;"><p id="reci">'.$data.'</p></div><div class="reci-wrapper" style="display: inline-block;"><p id="reci">'.$data1.'</p></div>';
                    $this->_api->chatStore(" ",$data);
                    $this->_api->chatStore(" ",$data1);
                    echo $res;                    
                }
        } else {
            $res = '<div class="customerdiv"><div class="reci-wrapper" style="display: inline-block;"><p id="reci"><input type="text" id="name" placeholder="Enter NAME" required="true"><input type="email" id="email" placeholder="Enter EMAIL" required="true"><button  type="button" id="newcustomer" class="newcustomer" >Submit</button></p></div></div>';
            echo $res;
        }
    }
}
