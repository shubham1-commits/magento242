<?php
namespace Elsnertech\Chatbot\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\RequestInterface;
use \Magento\Framework\Mail\Template\TransportBuilder;
use \Magento\Framework\Translate\Inline\StateInterface;
use Psr\Log\LoggerInterface;

class Test extends \Magento\Framework\App\Action\Action
{
    const XML_PATH_EMAIL_ADMIN_QUOTE_SENDER = 'shubham@elsner.com.au';
    const XML_PATH_EMAIL_ADMIN_QUOTE_NOTIFICATION = 'chatbot/email/myemail';
    const XML_PATH_EMAIL_ADMIN_NAME = 'shubham Mistri';
    const XML_PATH_EMAIL_ADMIN_EMAIL = 'shubham@elsner.com';

    protected $inlineTranslation;
    protected $transportBuilder;
    protected $_logLoggerInterface;

    public function __construct(
    Context $context,
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
    StateInterface $inlineTranslation,
    TransportBuilder $transportBuilder,
    LoggerInterface $logLoggerInterface)
    {
        $this->inlineTranslation = $inlineTranslation;
        $this->scopeConfig = $scopeConfig;
        $this->transportBuilder = $transportBuilder;
        $this->_logLoggerInterface = $logLoggerInterface;
        parent::__construct($context);
    }


    public function execute()
    {	
        // try
        // {
           $this->inlineTranslation->suspend();
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
            $transport = $this->transportBuilder->setTemplateIdentifier($this->scopeConfig->getValue(self::XML_PATH_EMAIL_ADMIN_QUOTE_NOTIFICATION, $storeScope))->setTemplateOptions([
                        'area' => 'frontend',
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,])->setTemplateVars([
	                    'var1'  => 'Value',
	                    'var2'  => 'Value'
            ])->setFrom($this->scopeConfig->getValue(self::XML_PATH_EMAIL_ADMIN_QUOTE_SENDER, $storeScope))->addTo($this->scopeConfig->getValue(self::XML_PATH_EMAIL_ADMIN_EMAIL, $storeScope))->getTransport();
            $transport->sendMessage();
            echo "sender";
            $this->inlineTranslation->resume();
        // } catch(\Exception $e){
        // 	echo "s";
        //     $this->_logLoggerInterface->debug($e->getMessage());
        //     exit;   
        // }
    }
}