<?php
namespace Elsnertech\Chatbot\Controller\Management;

class Generalinquiry extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $logincustomer,
        \Magento\Framework\View\Result\PageFactory $pageFactory
    ) {
        $this->_pageFactory = $pageFactory;
        $this->logincustomer = $logincustomer;
        return parent::__construct($context);
    }

    public function execute()
    {
        $loggin = $this->logincustomer;
        if ($loggin->isLoggedIn()) {
            $res = '<button id="productrelated" type="button" class="controller">Productrelated</button>
                    <button id="orderrelated" type="button" class="controller">order related</button>
                    <button id="websiterelated" type="button" class="controller">website related</button>
                    <button id="checkoutrelated" type="button" class="controller">Checkout related</button>
                    <button id="paymentrelated" type="button" class="controller">Payment related</button>
                    <button id="Other" type="button" class="controller">Other</button>
                    <button id="goback" type="button" class="controller">Go Back</button>';
            echo $res;
        } else {
            $res = 'Click Agree to create new Account';
            echo $res;
        }
    }
}
