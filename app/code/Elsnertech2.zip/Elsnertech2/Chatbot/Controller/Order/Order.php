<?php
namespace Elsnertech\Chatbot\Controller\Order;

class Order extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $logincustomer,
        \Elsnertech\Chatbot\Model\OrderApi $orderapi,
        \Magento\Framework\App\RequestInterface $request
    ) {
        $this->logincustomer = $logincustomer;
        $this->request = $request;
        $this->_orderapi = $orderapi;
        parent::__construct($context);
    }

    public function execute()
    {
        $loggin = $this->logincustomer;
        $post = $this->request->getParam('name');
        if ($loggin->isLoggedIn()) {
            $customerId = $loggin->getId();
            $this->_orderapi->orderStatus($customerId);
        } else {
            $res = 'Click Agree to create new Account';
            echo $res;
        }
    }
}
