<?php
namespace Elsnertech\Chatbot\Controller\Order;

class OrderInfo extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Elsnertech\Chatbot\Model\OrderApi $orderapi,
        \Magento\Framework\App\RequestInterface $request
    ) {
        $this->request = $request;
        $this->_orderapi = $orderapi;
        parent::__construct($context);
    }

    public function execute()
    {
        $id = $this->request->getParam('numone');
        $this->_orderapi->orderListinfo($id);
    }
}
