<?php
namespace Elsnertech\Chatbot\Controller\Order;

class OrderStatus extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\RequestInterface $request,
        \Elsnertech\Chatbot\Model\OrderApi $orderapi
    ) {
        $this->request = $request;
        $this->_orderapi = $orderapi;
        return parent::__construct($context);
    }

    public function execute()
    {
        $post = $this->request->getParam('numone');
        $this->_orderapi->orderStatusinfo($post);
    }
}
