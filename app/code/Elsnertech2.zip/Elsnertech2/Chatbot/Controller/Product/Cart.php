<?php
namespace Elsnertech\Chatbot\Controller\Product;

class Cart extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;
    protected $_productloader;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $customer,
        \Elsnertech\Chatbot\Model\ProductApi $productapi,
        \Magento\Framework\App\RequestInterface $request
    ) {

        $this->_request = $request;
        $this->_customer = $customer;
        $this->_productapi = $productapi;
        return parent::__construct($context);
    }

    public function execute()
    {
        $customer = $this->_customer;
        $sku = $this->_request->getParam('numone');
        $qty = 1;
        if ($customer->isLoggedIn()) {
            $customerId = $customer->getId();
            $this->_productapi->cartItem($sku);

        } else {
            echo "please sign-in";
        }
    }
}
