<?php
namespace Elsnertech\Chatbot\Model;

/**
 * Class OrderApi
 *
 * @package Elsnertech\Zohointegration\Model
 */

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

class OrderApi extends \Magento\Framework\Model\AbstractModel
{

    public function __construct(
        \Magento\Customer\Model\CustomerFactory $_customerloader,
        \Magento\Framework\Serialize\Serializer\Json $json,
        \Elsnertech\Chatbot\Model\Api $api,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
    ) {
        $this->_customerloader = $_customerloader;
        $this->_json = $json;
        $this->_orderFactory = $orderFactory;
        $this->_api = $api;
        $this->orderCollectionFactory = $orderCollectionFactory;
    }

    public function jsonConverted($data)
    {
        $res = $this->_json->serialize($data);
        echo $res;
    }

    public function orderStatus($customerId)
    {
        $customerOrder = $this->orderCollectionFactory->create()->addFieldToFilter('customer_id', $customerId);
        $t = count($customerOrder);
        $data = $customerOrder->getdata();
        if ($t!=0) {
            foreach ($data as $key) {
                $id = $key['increment_id'];
                $this->_api->chatStore(" ",$id);
                $post = " ";
                $this->_api->chatStore(" ",$id);
                $jsonArray[] = ["increment_id"=>$id];
            }
            $res = $this->_json->serialize($jsonArray);
            echo $res;
        } else {
            $jsonArray[] = "Order is not avalible";
            $res = $this->_json->serialize($jsonArray);
            echo $res;
        }
    }


    public function orderStatusinfo($post)
    {
        $order = $this->_orderFactory->create();
        $order = $order->loadByIncrementId($post);
        $shipcharge = $order->getShippingAmount();
        $customerid = $order->getCustomerId();
        $status = $order->getstatus();
        $orderItems = $order->getAllItems();
        $grandtotal = $order->getGrandTotal();
        $itemQty = [];
        foreach ($orderItems as $item) {
            $productname =  $item->getName();
            $producttype = $item->getProductType();
            if ($producttype!="configurable") {
                $res = [
                    "productname"=>$productname,
                    "status" => $status
                ];
                $rece[] = ["status" => "productname is"." ".$productname." "."status is"." ".$status];
                $this->_api->chatStore(" ",$rece);
            }
        }
            $res = $this->_json->serialize($rece);
            echo $res;
    }

    public function orderListinfo($id)
    {
        $order = $this->_orderFactory->create();
        $order = $order->loadByIncrementId($id);
        $shipcharge = $order->getshipping_amount();
        $customerid = $order->getCustomerId();
        $orderItems = $order->getAllItems();
        $grandtotal = $order->getbase_grand_total();
        $shipping = $order->getShippingAddress()->getData();
        $billing = $order->getBillingAddress()->getData();
        $itemQty = [];
        foreach ($orderItems as $item) {
            $qty = $item->getQtyOrdered();
            $total = $item->getrow_total();
            $price = $item->getprice();
            $productname =  $item->getname();
            if ($price!=0) {
                $price = $item->getPrice();
                $r = "product name is"." ".$productname." "."Qty is"." ".$qty." "."Total price is"." ".$total;
                $this->_api->chatStore(" ",$r);
                $res = $this->_json->serialize($r);
            }
        }
        echo $res;
    }
}
