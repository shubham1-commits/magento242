<?php
namespace Elsnertech\Chatbot\Model\ResourceModel\Customerchat;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'id';
    protected $_eventPrefix = 'customerchat';
    protected $_eventObject = 'post_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Elsnertech\Chatbot\Model\Customerchat', 'Elsnertech\Chatbot\Model\ResourceModel\Customerchat');
    }
}
