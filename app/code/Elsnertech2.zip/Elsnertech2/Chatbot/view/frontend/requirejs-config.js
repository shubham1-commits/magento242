var config = {
    map: {
        '*': {
            myscript: 'Elsnertech_Chatbot/js/chatbot',
        }
    }
};