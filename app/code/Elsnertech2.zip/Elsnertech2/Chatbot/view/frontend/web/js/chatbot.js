define(['jquery'], function ($) {
    "use strict";
    $(document).ready(function () {

        var nonlogin = '<div class="customerdiv"><div class="reci-wrapper" style="display: inline-block;"><p id="reci"><input type="text" id="name" placeholder="Enter NAME" required="true"><input type="email" id="email" placeholder="Enter EMAIL" required="true"><button  type="button" id="newcustomer" class="newcustomer" >Submit</button></p></div></div>';
        var test = jQuery('#url').val(); 
        var testvariable = "testdata";
        var glocalclass = "gbclass";

        var menudisplay = function() {
            $(".quick-replies").css("display", "flex");
        }

        var wrece = function(msg) {
            var receiver =  '<div class="reci-wrapper" style="display: inline-block;">'+msg+'</div>';
            $('.msg-wrap').append(receiver);
        }

        var typingadd = function (typeclass) {
        	var typingdata = '<button class="mainform'+typeclass+'" type="button"><div class="send-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24" xml:space="preserve"><path fill="#d7d7d7" d="M22,11.7V12h-0.1c-0.1,1-17.7,9.5-18.8,9.1c-1.1-0.4,2.4-6.7,3-7.5C6.8,12.9,17.1,12,17.1,12H17c0,0,0-0.2,0-0.2c0,0,0,0,0,0c0-0.4-10.2-1-10.8-1.7c-0.6-0.7-4-7.1-3-7.5C4.3,2.1,22,10.5,22,11.7z"></path></svg></div></button>';
        	$('.typing').append(typingdata);
        }

        var agree = function () {
            var agree = '<a href="'+test+'customer/account/create/" class="controller" target="blank">Agree</a><button class="controller" id="notagree">Not Agree</button>';
            $(".quick-replies").html(agree);
        }

        $(document).on('click','#goback',function () {
            $(".quick-replies").html(' ');
            $(".mainform").remove();
            $(".mainformwishadd").remove();
            typingadd('');
            var data = '<button id="order" class="controller">⚡️Order management</button>'+
                        '<button id="customer" class="controller">Customer management</button>'+ 
                        '<button id="product" class="controller">💲Product management</button>'+
                        '<button id="generalinquiry" class="controller">General support</button>';
            $(".quick-replies").html(data);
        });

        $(document).on('click','#notagree',function () {
            $(".quick-replies").html(' ');
            var data = '<button id="order" class="controller">⚡️Order management</button>'+
                        '<button id="customer" class="controller">Customer management</button>'+ 
                        '<button id="product" class="controller">💲Product management</button>'+
                        '<button id="generalinquiry" class="controller">General support</button>';
            $(".quick-replies").html(data);
        });

        var nonloginajax = function(url,info) {
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    numone: info
                },
                cache: false,
                success: function (response) {
                    $('.msg-wrap').append(response);
                    if(response!=nonlogin){
                        menudisplay();
                    }
                }
            });
        }
    
        var receivermsg = function (msg,classname) {
            var receiver =  '<div class="reci-wrapper" style="display: inline-block;"><p id="reci" class="'+classname+'">'+msg+'</p></div>';
            $('.msg-wrap').append(receiver);
            if (msg=="Geast is save") {
                menudisplay();                
            }
        }

        var receivermsgwclass = function (msg) {
            var receiver =  '<div class="reci-wrapper" style="display: inline-block;"><p id="reci">'+msg+'</p></div>';
            $('.msg-wrap').append(receiver);
            if (msg=="Geast is save") {
                menudisplay();                
            }
        }

        var parentremove = function(url) {
            $(".quick-replies").html(' ');
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    data : testvariable
                },
                cache: false,
                success: function (response) {
                    if(response=="Click Agree to create new Account"){
                        receivermsg(response);
                        agree();
                    }
                    else {
                        $(".quick-replies").html(response);
                    }
                }
            });
        }

        $('.open-button').click(function () {
            var url = test + "chatbot/index/index";
            var info = $('.msg-wrap').html();
            nonloginajax(url,info);
        });

        $(document).on('click', '.newcustomer', function () {
            var url = test + "chatbot/index/newcustomer";
            var name = $('#name').val();            
            var email = $('#email').val();
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    name: name,
                    email :email
                },
                cache: false,
                success: function (response) {
                    receivermsg(response);
                    menudisplay();
                    $('.customerdiv').remove();
                }
            });
        });

        $(document).on('click','#order',function () {
            var url = test + "chatbot/management/order";
            parentremove(url);
        });

        $(document).on('click','#customer',function () {
            var url = test + "chatbot/management/customer";
            parentremove(url);
        });

        $(document).on('click','#generalinquiry',function () {
            console.log("ds");
            var url = test + "chatbot/management/generalinquiry";
            parentremove(url);
        });

        $(document).on('click','#product',function () {
            var url = test + "chatbot/management/product";
            parentremove(url);
        });

       
        $(document).on('click','#orderlist  ',function () {
            var url = test + "chatbot/order/order";
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    name: testvariable
                },
                cache: false,
                success: function (response) {
                    var classname ="orderinfo";
                    response = JSON.parse(response);
                    for(var index in response) 
                    {
                        if(response[index].increment_id) {
                          receivermsg(response[index].increment_id,classname);
                        }
                        else{
                            receivermsg(response ,classname); 
                            $('.quick-replies').css("display","flex");
                        }
                    };
                }
            });
        });

        $(document).on('click','#orderstatus  ',function () {
            var url = test + "chatbot/order/order";
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    name: testvariable
                },
                cache: false,
                success: function (response) {
                    var classname ="orstatus";
                    response = JSON.parse(response);
                    for(var index in response) 
                    {
                        if(response[index].increment_id) {
                          receivermsg(response[index].increment_id,classname);
                        }
                        else{
                            receivermsg(response ,classname); 
                            $('.quick-replies').css("display","flex");
                        }
                    };
                }
            });
        });


        $(document).on('click','.orderinfo  ',function () {
            var url = test + "chatbot/order/orderinfo";
            var oneValue = jQuery(this).html();        
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    numone: oneValue
                },
                cache: false,
                success: function (response) {
                    response = JSON.parse(response);
                    receivermsg(response,glocalclass);
                }
            });
        });

        $(document).on('click','.orstatus  ',function () {
            var url = test + "chatbot/order/orderstatus";
            var oneValue = jQuery(this).html();        
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    numone: oneValue
                },
                cache: false,
                success: function (response) {
                    response = JSON.parse(response);
                    for(var index in response) 
                    {
                        if(response[index].status) {
                          receivermsg(response[index].status,glocalclass);
                        }
                        else{
                            receivermsg(response ,glocalclass); 
                            $('.quick-replies').css("display","flex");
                        }
                    };
                }
            });
        });

        $(document).on('click','#wishlist  ',function () {
            receivermsg("enter the prodct sku","test");
            $('.mainform').remove();
            $('#cart').hide();
            $('#wishlist').hide();
            typingadd("wishadd");
        });

        $(document).on('click','#cart  ',function () {
            receivermsg("enter the prodct sku","test");
            $('#cart').hide();
            $('#wishlist').hide();
            $('.mainform').remove();
            typingadd("cartadd");
        });

        $(document).on('click','.mainform  ',function () {
            console.log("message");
        });


        $(document).on('click','.mainformwishadd  ',function () {
            var url = test + "chatbot/product/product";
			var sku = $('#chat').val();        
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    numone: sku
                },
                cache: false,
                success: function (response) {
                    if(response=="Enter valid sku") {
                        $('#chat').val(' ');
                        receivermsgwclass(response);
                    } else {
                        wrece(response);
                        $('#chat').val(' ');
                    }
                }
        	});
        });

        $(document).on('click','.mainformcartadd  ',function () {
            var url = test + "chatbot/product/product";
			var sku = $('#chat').val();        
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    numone: sku
                },
                cache: false,
                success: function (response) {
                    if(response=="Enter valid sku") {
                        receivermsgwclass(response)
                    } else {
                        wrece(response);
                    }
                    $('#chat').val(' ');
                    $('#cart').show();
                    $('#wishlist').show();
                    $(".mainformcartadd").remove();
                    typingadd(" ");
                }
        	});
        });

        $(document).on('click','.wish  ',function () {
            var url = test + "chatbot/product/wishlist";
            var sku = $(this).val();        
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    numone: sku
                },
                cache: false,
                success: function (response) {
                  receivermsgwclass(response);
                }
            });
        });

        $(document).on('click','.maincart1  ',function () {
            var url = test + "chatbot/product/cart";
            var sku = $(this).val();        
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    numone: sku
                },
                cache: false,
                success: function (response) {
                   receivermsgwclass(response);
                }
            });
        });        

        $(document).on('click','#address  ',function () {
            var url = test + "chatbot/Customer/address";
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    numone: testvariable
                },
                cache: false,
                success: function (response) {
                   response = JSON.parse(response);
                   receivermsgwclass(response);
                }
            });
        });


        $(document).on('click','#forgotpassword  ',function () {
            var url = test + "chatbot/Customer/forgotpassword";
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {
                    numone: testvariable
                },
                cache: false,
                success: function (response) {
                   receivermsgwclass(response);
                }
            });
        });


            $(document).on('click','.configcart  ',function () {
                var url = test + "chatbot/product/cart";
                var a = $(this).text();
                jQuery.ajax({
                    url: url,
                    type: "POST",
                    data: {
                        numone: a
                    },
                    cache: false,
                    success: function (response) {
                       receivermsgwclass(response);
                    }
                });
            }); 

        $(document).on('click','#productrelated',function () {
            var url = test + "chatbot/management/customer";
            
        });
           
        $(document).on('click','#orderrelated',function () {
            var url = test + "chatbot/management/customer";
            
        });

        $(document).on('click','#websiterelated',function () {
            var url = test + "chatbot/management/customer";
                   
        });

        $(document).on('click','#checkoutrelated',function () {
            var url = test + "chatbot/management/customer";
            
        });

        $(document).on('click','#paymentrelated',function () {
            var url = test + "chatbot/management/customer";
            
        });

        $(document).on('click','#Other',function () {
            var url = test + "chatbot/management/customer";
            
        });
        

    });
});
