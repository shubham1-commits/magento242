<?php
namespace Elsnertech\Zohointegration\Model;

/**
 * Class CustomerApi
 *
 * @package Elsnertech\Zohointegration\Model
 */

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

class CustomerApi extends \Magento\Framework\Model\AbstractModel
{

}
