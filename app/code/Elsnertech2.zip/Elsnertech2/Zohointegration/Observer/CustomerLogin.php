<?php
namespace Elsnertech\Zohointegration\Observer;

/**
 * Class CustomerLogin
 *
 * @package Elsnertech\Zohointegration\Observer
 */
use Magento\Framework\Event\ObserverInterface;

class CustomerLogin implements ObserverInterface
{
    protected $_request;
    protected $_customerApi;

    public function __construct(
        \Magento\Framework\App\Request\Http $request,
        \Elsnertech\Zohointegration\Model\CustomerApi $CustomerApi
    ) {
        $this->_request = $request;
        $this->_customerApi = $CustomerApi;
    }
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $data = $this->_request->getParams();
        $id = $data['id'];
        echo $id;die();
    }
}
