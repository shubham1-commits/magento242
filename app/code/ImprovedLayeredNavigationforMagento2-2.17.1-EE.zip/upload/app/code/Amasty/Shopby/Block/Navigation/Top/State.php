<?php

namespace Amasty\Shopby\Block\Navigation\Top;

/**
 * @api
 */
class State extends \Amasty\Shopby\Block\Navigation\State
{
    public function getActiveFilters()
    {
        return [];
    }
}
