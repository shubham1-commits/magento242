<?php

namespace Searchanise\SearchAutocomplete\Controller\Adminhtml\Searchanise;

use \Magento\Backend\App\Action;

class Terms extends Action
{
    public function execute()
    {
        // TODO: add wrapper for non-ajax requests - LOW priority
        // return terms text pulled from server
        return '';
    }
}
