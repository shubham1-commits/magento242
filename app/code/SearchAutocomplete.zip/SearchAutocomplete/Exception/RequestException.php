<?php

namespace Searchanise\SearchAutocomplete\Exception;

/**
 * Request exeption
 */
class RequestException extends \Exception
{

}
