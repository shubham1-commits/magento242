<?php

namespace Searchanise\SearchAutocomplete\Model\Mysql4\Queue;

class CollectionFactory
{
}
