var config = {
    map: {
        '*': {
            quickSearch: 'Searchanise_SearchAutocomplete/js/disableautosuggest'
        }
    }
}
