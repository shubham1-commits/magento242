# RequireJS is not covered
This extension does not support scripts that are loaded via RequireJS. RequireJS itself (the core libraries) is served using a `Link` header though. If you want to optimize RequireJS sources, make sure to look into bundling instead.

