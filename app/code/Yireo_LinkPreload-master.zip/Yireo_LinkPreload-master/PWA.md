# PWA compatibility
This frontend extension will be completely replaced by React or Vue functionality, and therefore, this extension
will not be made compatible with PWA.
