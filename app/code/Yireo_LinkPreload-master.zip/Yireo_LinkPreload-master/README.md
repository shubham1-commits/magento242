# Yireo LinkPreload
Magento 2 extension to set HTTP Link headers for primary resources to allow for HTTP/2 preloading.

Note: This module was formally known as `Yireo_ServerPush` but the name gave a wrong impression (referring to the HTTP/2 `PUSH` feature). Hence this module was renamed.

## See also:
- [Installation](INSTALL.md)
- [Usage](USAGE.md)
- [Notes](NOTES.md)
