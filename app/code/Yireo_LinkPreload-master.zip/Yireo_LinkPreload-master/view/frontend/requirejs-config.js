var config = {
    paths: {
        "linkpreload": "Yireo_LinkPreload/js/cookie"
    }
};
