define([
    'jquery',
    'jquery/jquery.cookie'
], function ($) {
    'use strict';

    $.cookie('linkpreload', 1);
});
