<?php
/**
 * @author Elsner Team
 * @copyright Copyright (c) 2021 Elsner Technologies Pvt. Ltd (https://www.elsner.com/)
 * @package Elsnertech_SignupNotification
 */

namespace Elsnertech\SignupNotification\Observer;

class Notification implements \Magento\Framework\Event\ObserverInterface
{
    protected $_sendEmailHelper;

    public function __construct(
        \Elsnertech\SignupNotification\Helper\Send $sendEmailHelper
    ) {
        $this->_sendEmailHelper = $sendEmailHelper;
    }

    /**
     * @param Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $customer = $observer->getEvent()->getCustomer();
        if ($this->_sendEmailHelper->isEnabled()) {
            if ($customer->isObjectNew()) {
                $variables = [
                'customer_email' => $customer->getEmail(),
                'customer_name' => $customer->getFirstname().' '.$customer->getLastname()
                ];
                $this->_sendEmailHelper->sendMail($variables);
            }
            return $this;
        }
    }
}
