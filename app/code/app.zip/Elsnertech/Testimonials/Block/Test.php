<?php

namespace Elsner\Testimonials\Block;

use Elsner\Testimonials\Model\CmFactory;

/**
 * Test content block
 */
class Test extends \Magento\Framework\View\Element\Template
{
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        CmFactory $test
    ) {
        $this->_test = $test;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Simple Custom Module'));
        
        return parent::_prepareLayout();
    }
    public function getTestCollection()
    {
        $test = $this->_test->create();
        $collection = $test->getCollection();
        // $collection->addFieldToFilter('status','1');
        return $collection;
    }
}
