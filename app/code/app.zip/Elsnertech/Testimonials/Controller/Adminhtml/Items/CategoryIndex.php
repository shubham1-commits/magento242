<?php


namespace Elsner\Testimonials\Controller\Adminhtml\Items;

class CategoryIndex extends \Elsner\Testimonials\Controller\Adminhtml\Items
{
    /**
     * Items list.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Elsner_Testimonials::category');
        $resultPage->getConfig()->getTitle()->prepend(__('category List'));
        $resultPage->addBreadcrumb(__('Test'), __('Test'));
        $resultPage->addBreadcrumb(__('Items'), __('Items'));
        return $resultPage;
    }
}
