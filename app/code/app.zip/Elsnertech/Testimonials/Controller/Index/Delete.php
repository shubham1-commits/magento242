<?php
 
namespace Elsner\Testimonials\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Elsner\Testimonials\Model\PMFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Action;
 
class Delete extends Action
{
    protected $resultPageFactory;
    protected $PMFactory;
 
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        PMFactory $PMFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->PMFactory = $PMFactory;
        parent::__construct($context);
    }
 
    public function execute()
    {
        try {
            $data = (array)$this->getRequest()->getParams();
            if ($data) {
                $test = $this->PMFactory->create()->load($data['id']);
                $test->delete();
                $this->messageManager->addSuccessMessage(__("Record Delete Successfully."));
            }
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e, __("We can\'t delete record, Please try again."));
        }
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }
}
