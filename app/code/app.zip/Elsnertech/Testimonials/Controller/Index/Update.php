<?php

namespace Elsner\Testimonials\Controller\Index;

use Magento\Framework\App\Action\Context;
use Elsner\Testimonials\Model\PMFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Image\AdapterFactory;
use Magento\Framework\Filesystem;

class Update extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Test
     */
    protected $_test;
    protected $uploaderFactory;
    protected $adapterFactory;
    protected $filesystem;


    public function __construct(
        Context $context,
        PMFactory $test,
        UploaderFactory $uploaderFactory,
        AdapterFactory $adapterFactory,
        Filesystem $filesystem
    ) {
        $this->_test = $test;
        $this->uploaderFactory = $uploaderFactory;
        $this->adapterFactory = $adapterFactory;
        $this->filesystem = $filesystem;
        parent::__construct($context);
    }
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $a = $this->getRequest()->getfiles('profile_image');
        $a = 'Elsner/Testimonials/'.$a['name'];
        $data = $this->getRequest()->getParams();
        // echo "<pre>"; print_r($data);
        // die();

        if ($id != "") { //edit
            $test = $this->_test->create();
            $a1 = $test->load($id);
            $data['profile_image']=$a;
            $test->setData('firstname', $data['firstname']);
            $test->setData('lastname', $data['lastname']);
            $test->setData('testimonials_description', $data['testimonials_description']);
            $test->setData('profile_image', $data['profile_image']);
        } else {
            echo "False";
        }

        if (isset($_FILES['profile_image']['name']) && $_FILES['profile_image']['name'] != '') {
            try {
                $uploaderFactory = $this->uploaderFactory->create(['fileId' => 'profile_image']);
                $uploaderFactory->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
                $imageAdapter = $this->adapterFactory->create();
                $uploaderFactory->addValidateCallback('custom_image_upload', $imageAdapter, 'validateUploadFile');
                $uploaderFactory->setAllowRenameFiles(true);
                $uploaderFactory->setFilesDispersion(true);
                $mediaDirectory = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA);
                $destinationPath = $mediaDirectory->getAbsolutePath('Elsner/Testimonials');
                $result = $uploaderFactory->save($destinationPath);
                if (!$result) {
                    throw new LocalizedException(
                        __('File cannot be saved to path: $1', $destinationPath)
                    );
                }
                $imagePath = 'Elsner/Testimonials/'.$result['file'];
                $data['profile_image'] = $imagePath;
            } catch (\Exception $e) {
            }
        }

        $test = $this->_test->create();
        $test->setData($data);
        if ($test->save($data['id'])) {
            $this->messageManager->addSuccessMessage(__('You updated the data.'));
        } else {
            $this->messageManager->addErrorMessage(__('Data was not saved.'));
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath('test/index/listdata');
        return $resultRedirect;
    }
}
