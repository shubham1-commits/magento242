<?php
namespace Elsner\Testimonials\Model;

class Cm extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
    const CACHE_TAG = 'categories';

    protected $_cacheTag = 'categories';

    protected $_eventPrefix = 'categories';

    protected function _construct()
    {
        $this->_init('Elsner\Testimonials\Model\ResourceModel\Cm');
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
}
