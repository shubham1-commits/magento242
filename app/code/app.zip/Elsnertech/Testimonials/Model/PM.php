<?php
namespace Elsner\Testimonials\Model;

class PM extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
    const CACHE_TAG = 'profiles';

    protected $_cacheTag = 'profiles';

    protected $_eventPrefix = 'profiles';

    protected function _construct()
    {
        $this->_init('Elsner\Testimonials\Model\ResourceModel\PM');
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
}
