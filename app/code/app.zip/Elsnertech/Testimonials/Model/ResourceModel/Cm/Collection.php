<?php
namespace Elsner\Testimonials\Model\ResourceModel\Cm;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'category_id';
    protected $_eventPrefix = 'categories_collection';
    protected $_eventObject = 'Cm_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Elsner\Testimonials\Model\Cm', 'Elsner\Testimonials\Model\ResourceModel\Cm');
    }
}


/*The collection model is considered a resource model which allow us to filter and fetch a collection table data.*/
/*The CRUD collection class must extends from \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection and call the _init() method to init the model, resource model in _construct() function.*/
