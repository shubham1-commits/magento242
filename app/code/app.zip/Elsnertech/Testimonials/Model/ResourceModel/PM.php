<?php
namespace Elsner\Testimonials\Model\ResourceModel;

class PM extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb    //Every CRUD resource model in Magento must extends abstract class
{

                                                                          //\Magento\Framework\Model\ResourceModel\Db\AbstractDb which
                                                                          // contain the functions for fetching information from database.

    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context
    ) {
        parent::__construct($context);
    }
    
    protected function _construct()
    {
        $this->_init('profiles', 'id');
    }
}


/*Like model class, this resource model class will have required method _construct(). This method will call _init() function to define the table name and primary key for that table*/
