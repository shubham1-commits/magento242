<?php
namespace Elsner\Testimonials\Model\ResourceModel\PM;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'id';
    protected $_eventPrefix = 'profiles_collection';
    protected $_eventObject = 'PM_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Elsner\Testimonials\Model\PM', 'Elsner\Testimonials\Model\ResourceModel\PM');
    }

    protected function _initSelect()
    {
        parent::_initSelect();
 
          $r = $this->getSelect()->joinLeft(
              ['secondTable' => $this->getTable('categories')], //2nd table name by which you want to join mail table
              'main_table.category_id = secondTable.category_id', // common column which available in both table
              '*' // '*' define that you want all column of 2nd table. if you want some particular column then you can define as ['column1','column2']
          );
          // $this->addFilterToMap('category_name', 'category_name');
          // $this->addFieldToFilter('category_name', 'main_table.category_id = secondTable.category_id');
    }


    // protected function _initSelect()
    // {
    //     parent::_initSelect();
    //     // $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

    //     // $connection = $this->objectManager->create('\Magento\Framework\App\ResourceConnection');
    //     // $conn = $connection->getConnection();
    //     $select = $this->getSelect()
    //     // ->from(
    //     //     ['main_table' => 'profiles'],
    //     //     ['main_table.id','custom_table.category_id']
    //     // )
    //     ->join(
    //         ['custom_table'=>'categories'],
    //         'main_table.category_id = custom_table.category_id'
    //     );
    //     // $data = $this->fetchAll($select);
    // }
}




/*The collection model is considered a resource model which allow us to filter and fetch a collection table data.*/
/*The CRUD collection class must extends from \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection and call the _init() method to init the model, resource model in _construct() function.*/
