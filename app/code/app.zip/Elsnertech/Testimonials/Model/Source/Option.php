<?php
/**
 * Webkul_Grid Status Options Model.
 * @category    Webkul
 * @author      Webkul Software Private Limited
 */
namespace Elsner\Testimonials\Model\Source;

use Magento\Framework\Option\ArrayInterface;
use Elsner\Testimonials\Model\CmFactory;

class Option implements ArrayInterface
{
    protected $options;
    public function __construct(
        // \Magento\Framework\View\Element\Template\Context $context,
        CmFactory $test
    ) {
        $this->_test = $test;
        // parent::__construct($context);
    }

    /**
     * Get Grid row status type labels array.
     * @return array
     */


    public function toOptionArray()
    {
        $sellerModel = $this->_test->create()->getCollection()
                                           ->addFieldToSelect(['category_id','category_name']);

        $options = [ 'label' => 'Please select', 'value' => ''  ];
        if ($sellerModel->getSize()) {
            foreach ($sellerModel as $seller) {
                $options[] = [
                'label' => ucfirst($seller->getData('category_name')) ,
                'value' => $seller->getData('category_id')
                ];
            }
        }

        return $options;
    }

    // public function getOptionArray()
    // {
    //     $test = $this->_test->create();
    //     $collection = $test->getCollection();

    //     foreach ($collection as $key => $value) {
    //         $options = [$value->getcategory_id() => __($value->getcategory_name())];
    //         return $options;
    //     }
        // $options = ['1' => __('Enabled'),'0' => __('Disabled')];
        // return $options;
    // }

    /**
     * Get Grid row status labels array with empty value for option element.
     *
     * @return array
     */
    // public function getAllOptions()
    // {
    //     $res = $this->getOptions();
    //     array_unshift($res, ['value' => '', 'label' => '']);
    //     return $res;
    // }

    /**
     * Get Grid row type array for option element.
     * @return array
     */
    // public function getOptions()
    // {
    //     $res = [];
    //     foreach ($this->getOptionArray() as $index => $value) {
    //         $res[] = ['value' => $index, 'label' => $value];
    //     }
    //     return $res;
    // }

    /**
     * {@inheritdoc}
     */
    // public function toOptionArray()
    // {
    //     return $this->getOptions();
    // }
}
