<?php

namespace Elsner\Testimonials\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\DB\Ddl\Table;

class UpgradeSchema implements UpgradeSchemaInterface
{

/**
 * Upgrades DB schema for a module
 *
 * @param SchemaSetupInterface $setup
 * @param ModuleContextInterface $context
 * @return void
 */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        if (version_compare($context->getVersion(), '3.8.1', '<')) {
            //     $setup->getConnection()->changeColumn(
            //     $setup->getTable('profiles'),
            //     'testimonials description',                                        //column name
            //     'testimonials_description',                                        //new column name
            //     [
            //         'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            //         'length' => 255,
            //         'comment' => 'testimonials description'
            //     ]
            // );
            // $setup->getConnection()->changeColumn(
            //     $setup->getTable('profiles'),
            //     'profile image',
            //     'profile_image',
            //     [
            //         'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            //         'length' => 255,
            //         'comment' => 'profile image'
            //     ]
            // );
            // $setup->getConnection()->changeColumn(
            //     $setup->getTable('profiles'),
            //     'created at',
            //     'created_at',
            //     [
            //         'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
            //         'length' => null,
            //         'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT,
            //         'comment' => 'created at'
            //     ]
            // );
            // $setup->getConnection()->changeColumn(
            //     $setup->getTable('profiles'),
            //     'updated at',
            //     'updated_at',
            //     [
            //         'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
            //         'length' => null,
            //         'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT_UPDATE,
            //         'comment' => 'updated at'
            //     ]
            // );
             // $setup->getConnection()->dropColumn($setup->getTable('profiles'), 'category_depth');
            $categories = $setup->getTable('categories');
            if ($setup->getConnection()->isTableExists($categories) != true) {
                $tableCategories = $setup->getConnection()
                    ->newTable($categories)
                     ->addColumn(
                         'category_id',
                         \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                         null,
                         ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                         'Id'
                     )
                     ->addColumn(
                         'category_name',
                         \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                         null,
                         ['nullable' => false, 'default' => ''],
                         'category_name'
                     );
                     $setup->getConnection()->createTable($tableCategories);
            }

            $setup->getConnection()->addColumn($setup->getTable('profiles'), 'category_id', [
            'type'     => Table::TYPE_INTEGER,
            'nullable' => true,
            'default' => 0,
            'comment'  => 'category_id'
            ]);
        } else {
            die("Test");
        }
        $setup->endSetup();
    }
}
