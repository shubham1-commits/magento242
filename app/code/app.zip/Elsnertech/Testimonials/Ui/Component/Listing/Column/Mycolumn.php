<?php
namespace Elsner\Testimonials\Ui\Component\Listing\Column;
 
use \Magento\Sales\Api\OrderRepositoryInterface;
use \Magento\Framework\View\Element\UiComponent\ContextInterface;
use \Magento\Framework\View\Element\UiComponentFactory;
use \Magento\Ui\Component\Listing\Columns\Column;
use \Magento\Framework\Api\SearchCriteriaBuilder;
use \Elsner\Testimonials\Model\PMFactory;
 
class Mycolumn extends Column
{
 
    protected $_orderRepository;
    protected $_searchCriteria;
    protected $_PMfactory;
 
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        OrderRepositoryInterface $orderRepository,
        SearchCriteriaBuilder $criteria,
        PMFactory $PMFactory,
        array $components = [],
        array $data = []
    ) {
        $this->_orderRepository = $orderRepository;
        $this->_searchCriteria  = $criteria;
        $this->_PMfactory = $PMFactory;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }
 
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            $i = 0;
            foreach ($dataSource['data']['items'] as & $item) {
                $collection = $this->_PMfactory->create()->getCollection();
                $data = $collection->getData();
                // echo "<pre>";
                // print_r($data);
                // die();
                 $item[$this->getData('name')] = $data[$i]['category_name'];
                 $i++;
                
            }
            return $dataSource;
        }
    }
}
