<?php

namespace Laminas\Validator\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
