<?php

namespace Laminas\Validator\Exception;

class InvalidMagicMimeFileException extends InvalidArgumentException
{
}
