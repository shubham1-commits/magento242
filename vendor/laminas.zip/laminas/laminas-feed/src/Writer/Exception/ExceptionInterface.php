<?php

/**
 * @see       https://github.com/laminas/laminas-feed for the canonical source repository
 * @copyright https://github.com/laminas/laminas-feed/blob/master/COPYRIGHT.md
 * @license   https://github.com/laminas/laminas-feed/blob/master/LICENSE.md New BSD License
 */

namespace Laminas\Feed\Writer\Exception;

/**
 * Feed exceptions
 *
 * Interface to represent exceptions that occur during Feed operations.
 */
interface ExceptionInterface
{
}
